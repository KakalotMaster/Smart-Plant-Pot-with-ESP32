#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// ---------- CONFIG ----------
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
#define MOISTURE_PIN 32   // D15 (GPIO15) - moisture sensor AO
#define BUTTON_PIN 23

#define DRY_VALUE 4095
#define WET_VALUE 1900
#define DRY_THRESHOLD 30

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// ---------- STATE ----------
enum Screen { MOISTURE, HISTORY, STATS, PREDICTION };
Screen currentScreen = MOISTURE;

#define HISTORY_SIZE 20
int moistureHistory[HISTORY_SIZE];
unsigned long historyTimestamps[HISTORY_SIZE];
int historyIndex = 0;
bool historyFull = false;

int minMoisture = 100;
int maxMoisture = 0;
long sumMoisture = 0;
int readCount = 0;

unsigned long lastWatered = 0;
int wateringStreak = 0;

unsigned long buttonDownTime = 0;
bool buttonWasDown = false;
const unsigned long LONG_PRESS_MS = 1500;
const unsigned long READ_INTERVAL_MS = 30000;
unsigned long lastReadTime = 0;

int currentPercent = 0;

// ---------- ANIMATION STATE ----------
enum EmotionState { HAPPY_ANIM, THIRSTY_ANIM, NEUTRAL_ANIM, NONE };
EmotionState activeAnim = NONE;
unsigned long animStartTime = 0;
int animFrame = 0;
const unsigned long FRAME_MS = 150;

// ---------- SETUP ----------
void setup() {
  Serial.begin(115200);
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  analogReadResolution(12);

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("OLED init failed");
    while (1);
  }
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);

  splashScreen();
  readMoisture();
}

// ---------- LOOP ----------
void loop() {
  handleButton();

  if (millis() - lastReadTime > READ_INTERVAL_MS) {
    readMoisture();
    lastReadTime = millis();
  }

  drawScreen();
  delay(50);
}

// ---------- SENSOR ----------
void readMoisture() {
  int raw = analogRead(MOISTURE_PIN);
  int percent = map(raw, DRY_VALUE, WET_VALUE, 0, 100);
  percent = constrain(percent, 0, 100);
  currentPercent = percent;

  moistureHistory[historyIndex] = percent;
  historyTimestamps[historyIndex] = millis();
  historyIndex = (historyIndex + 1) % HISTORY_SIZE;
  if (historyIndex == 0) historyFull = true;

  if (percent < minMoisture) minMoisture = percent;
  if (percent > maxMoisture) maxMoisture = percent;
  sumMoisture += percent;
  readCount++;

  Serial.printf("Moisture: %d%% (raw %d)\n", percent, raw);
}

// ---------- BUTTON ----------
void handleButton() {
  bool isDown = (digitalRead(BUTTON_PIN) == LOW);

  if (isDown && !buttonWasDown) {
    buttonDownTime = millis();
    buttonWasDown = true;
  }

  if (!isDown && buttonWasDown) {
    unsigned long heldFor = millis() - buttonDownTime;
    buttonWasDown = false;

    if (heldFor >= LONG_PRESS_MS) {
      markWatered();
    } else {
      currentScreen = (Screen)((currentScreen + 1) % 4);
    }
  }
}

void markWatered() {
  lastWatered = millis();
  wateringStreak++;
  triggerHappyAnimation();

  display.clearDisplay();
  display.setTextSize(1);
  display.setCursor(5, 15);
  display.println("Watered!");
  display.setCursor(5, 28);
  display.printf("Streak: %d", wateringStreak);
  display.display();
  delay(1200);
}

// ---------- DRAWING ----------
void drawScreen() {
  display.clearDisplay();

  switch (currentScreen) {
    case MOISTURE:   drawMoistureScreen(); break;
    case HISTORY:    drawHistoryScreen();  break;
    case STATS:      drawStatsScreen();    break;
    case PREDICTION: drawPredictionScreen(); break;
  }

  if (currentPercent < DRY_THRESHOLD && (millis() / 500) % 2 == 0) {
    display.drawRect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, SSD1306_WHITE);
  }

  display.display();
}

void drawMoistureScreen() {
  display.setTextSize(1);
  display.setCursor(2, 0);
  display.print("Moisture");

  display.setTextSize(2);
  display.setCursor(2, 12);
  display.printf("%d%%", currentPercent);

  updateAndDrawEmotion(currentPercent);
}

// ---------- EMOTION ENGINE ----------
void updateAndDrawEmotion(int percent) {
  EmotionState desired = NEUTRAL_ANIM;
  if (percent < DRY_THRESHOLD) desired = THIRSTY_ANIM;

  if (desired != activeAnim && activeAnim != HAPPY_ANIM) {
    activeAnim = desired;
    animStartTime = millis();
    animFrame = 0;
  }

  unsigned long elapsed = millis() - animStartTime;
  animFrame = (elapsed / FRAME_MS) % 8;

  switch (activeAnim) {
    case HAPPY_ANIM:   drawHappyFrame(animFrame); break;
    case THIRSTY_ANIM: drawThirstyFrame(animFrame); break;
    default:            drawNeutralFrame(animFrame); break;
  }

  if (activeAnim == HAPPY_ANIM && elapsed > 1500) {
    activeAnim = desired;
    animStartTime = millis();
  }
}

void triggerHappyAnimation() {
  activeAnim = HAPPY_ANIM;
  animStartTime = millis();
  animFrame = 0;
}

void drawHappyFrame(int frame) {
  int cx = 42, cy = 24;
  int bounce = (frame < 4) ? frame : (7 - frame);
  int y = cy - bounce;

  display.drawCircle(cx, y, 12, SSD1306_WHITE);

  if (frame % 2 == 0) {
    display.drawLine(cx - 6, y - 3, cx - 3, y - 6, SSD1306_WHITE);
    display.drawLine(cx - 3, y - 6, cx, y - 3, SSD1306_WHITE);
    display.drawLine(cx + 2, y - 3, cx + 5, y - 6, SSD1306_WHITE);
    display.drawLine(cx + 5, y - 6, cx + 8, y - 3, SSD1306_WHITE);
  } else {
    display.fillCircle(cx - 4, y - 3, 2, SSD1306_WHITE);
    display.fillCircle(cx + 5, y - 3, 2, SSD1306_WHITE);
  }

  display.drawLine(cx - 6, y + 4, cx - 3, y + 8, SSD1306_WHITE);
  display.drawLine(cx - 3, y + 8, cx + 3, y + 8, SSD1306_WHITE);
  display.drawLine(cx + 3, y + 8, cx + 6, y + 4, SSD1306_WHITE);

  int rayLen = 3 + (frame % 4);
  display.drawLine(cx - 16, y, cx - 16 - rayLen, y, SSD1306_WHITE);
  display.drawLine(cx + 16, y, cx + 16 + rayLen, y, SSD1306_WHITE);
  display.drawLine(cx, y - 16, cx, y - 16 - rayLen, SSD1306_WHITE);
  display.drawLine(cx - 11, y - 11, cx - 11 - rayLen/2, y - 11 - rayLen/2, SSD1306_WHITE);
  display.drawLine(cx + 11, y - 11, cx + 11 + rayLen/2, y - 11 - rayLen/2, SSD1306_WHITE);

  int dropY = 2 + ((frame * 4) % 20);
  display.fillCircle(cx - 14, dropY, 1, SSD1306_WHITE);
}

void drawThirstyFrame(int frame) {
  int cx = 42, cy = 22;
  int droop = frame % 2;

  display.drawCircle(cx, cy + droop, 11, SSD1306_WHITE);

  display.drawLine(cx - 7, cy - 2, cx - 3, cy, SSD1306_WHITE);
  display.drawLine(cx + 3, cy, cx + 7, cy - 2, SSD1306_WHITE);

  display.drawLine(cx - 5, cy + 9, cx - 2, cy + 6, SSD1306_WHITE);
  display.drawLine(cx - 2, cy + 6, cx + 2, cy + 6, SSD1306_WHITE);
  display.drawLine(cx + 2, cy + 6, cx + 5, cy + 9, SSD1306_WHITE);

  int sweatY = cy - 8 + (frame * 3) % 18;
  display.drawCircle(cx + 12, sweatY, 2, SSD1306_WHITE);

  int sway = (frame % 4 < 2) ? 1 : -1;
  display.drawLine(4, 40, 4 + sway, 30, SSD1306_WHITE);
  display.drawLine(4 + sway, 30, 8 + sway, 34, SSD1306_WHITE);
  display.drawLine(4 + sway, 30, 1 + sway, 25, SSD1306_WHITE);
}

void drawNeutralFrame(int frame) {
  int cx = 42, cy = 24;
  int breathe = (frame < 4) ? frame / 2 : (7 - frame) / 2;

  display.drawCircle(cx, cy, 11 + breathe, SSD1306_WHITE);
  display.fillCircle(cx - 4, cy - 2, 1, SSD1306_WHITE);
  display.fillCircle(cx + 4, cy - 2, 1, SSD1306_WHITE);
  display.drawLine(cx - 3, cy + 6, cx + 3, cy + 6, SSD1306_WHITE);
}

// ---------- OTHER SCREENS ----------
void drawHistoryScreen() {
  display.setTextSize(1);
  display.setCursor(2, 0);
  display.print("History");

  int count = historyFull ? HISTORY_SIZE : historyIndex;
  if (count < 2) {
    display.setCursor(2, 20);
    display.print("Collecting...");
    return;
  }

  int graphX = 2, graphY = 12, graphW = 80, graphH = 30;
  display.drawRect(graphX, graphY, graphW, graphH, SSD1306_WHITE);

  for (int i = 0; i < count - 1; i++) {
    int idx1 = historyFull ? (historyIndex + i) % HISTORY_SIZE : i;
    int idx2 = historyFull ? (historyIndex + i + 1) % HISTORY_SIZE : i + 1;

    int x1 = graphX + (i * graphW) / count;
    int x2 = graphX + ((i + 1) * graphW) / count;
    int y1 = graphY + graphH - (moistureHistory[idx1] * graphH / 100);
    int y2 = graphY + graphH - (moistureHistory[idx2] * graphH / 100);

    display.drawLine(x1, y1, x2, y2, SSD1306_WHITE);
  }
}

void drawStatsScreen() {
  display.setTextSize(1);
  display.setCursor(2, 0);
  display.print("Stats");

  display.setCursor(2, 12);
  display.printf("Min: %d%%", minMoisture);
  display.setCursor(2, 22);
  display.printf("Max: %d%%", maxMoisture);
  display.setCursor(2, 32);
  int avg = readCount > 0 ? (int)(sumMoisture / readCount) : 0;
  display.printf("Avg: %d%%", avg);
}

void drawPredictionScreen() {
  display.setTextSize(1);
  display.setCursor(2, 0);
  display.print("Forecast");

  int count = historyFull ? HISTORY_SIZE : historyIndex;
  if (count < 3) {
    display.setCursor(2, 20);
    display.print("Need more data");
    return;
  }

  int oldestIdx = historyFull ? historyIndex : 0;
  int newestIdx = (historyIndex - 1 + HISTORY_SIZE) % HISTORY_SIZE;

  int oldVal = moistureHistory[oldestIdx];
  int newVal = moistureHistory[newestIdx];
  long timeSpanMs = historyTimestamps[newestIdx] - historyTimestamps[oldestIdx];

  if (timeSpanMs <= 0 || newVal >= oldVal) {
    display.setCursor(2, 20);
    display.print("Stable/rising");
    return;
  }

  float dropPerMs = (float)(oldVal - newVal) / timeSpanMs;
  float msUntilDry = (newVal - DRY_THRESHOLD) / dropPerMs;

  if (msUntilDry < 0) {
    display.setCursor(2, 20);
    display.print("Water now!");
    return;
  }

  float daysUntilDry = msUntilDry / (1000.0 * 60 * 60 * 24);
  display.setCursor(2, 15);
  display.print("Days left:");
  display.setTextSize(2);
  display.setCursor(2, 26);
  display.printf("%.1f", daysUntilDry);
}

void splashScreen() {
  display.clearDisplay();
  display.setTextSize(1);
  display.setCursor(10, 15);
  display.println("Plant Pal");
  display.setCursor(10, 28);
  display.println("booting...");
  display.display();
  delay(1500);
}
