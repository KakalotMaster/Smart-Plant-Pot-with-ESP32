/ Use the code if you think your screen is broken/doesn't work

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 84
#define SCREEN_HEIGHT 48
#define OLED_RESET -1

#define SDA_PIN D2  // GPIO4
#define SCL_PIN D1  // GPIO5

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println("Starting OLED test...");

  Wire.begin(SDA_PIN, SCL_PIN);

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("SSD1306 allocation failed at 0x3C");
    if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3D)) {
      Serial.println("Also failed at 0x3D. Screen not responding.");
      while (1) delay(1000);
    }
  }

  Serial.println("OLED initialized successfully!");

  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.println("Hello!");
  display.println("Screen OK");
  display.display();
}

void loop() {
  static bool on = true;
  display.drawPixel(0, 0, on ? SSD1306_WHITE : SSD1306_BLACK);
  display.display();
  on = !on;
  delay(500);
}
