#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// Set this generously large — bigger than you think the screen is.
// The library will just clip anything outside the real panel.
// İf the code works and you see borders at the corners of your screen, it means its dimensions are 128x64
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1

#define SDA_PIN 4
#define SCL_PIN 5

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

void setup() {
  Serial.begin(115200);
  delay(1000);
  Wire.begin(SDA_PIN, SCL_PIN);

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("Failed to init at 0x3C, trying 0x3D...");
    if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3D)) {
      Serial.println("Screen not responding at all.");
      while (1) delay(1000);
    }
  }

  display.clearDisplay();

  // Draw a full border rectangle at max assumed size
  display.drawRect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, SSD1306_WHITE);

  // Corner markers - small L-shapes so you can spot exactly where they get cut off
  drawCornerMark(0, 0);
  drawCornerMark(SCREEN_WIDTH - 10, 0);
  drawCornerMark(0, SCREEN_HEIGHT - 10);
  drawCornerMark(SCREEN_WIDTH - 10, SCREEN_HEIGHT - 10);

  // Ruler ticks every 10px along top and left edge, with numbers
  display.setTextSize(1);
  for (int x = 0; x < SCREEN_WIDTH; x += 10) {
    display.drawLine(x, 0, x, 3, SSD1306_WHITE);
  }
  for (int y = 0; y < SCREEN_HEIGHT; y += 10) {
    display.drawLine(0, y, 3, y, SSD1306_WHITE);
  }

  // Print the assumed dimensions in the center so you can compare vs what's visible
  display.setCursor(SCREEN_WIDTH / 4, SCREEN_HEIGHT / 2 - 4);
  display.print(SCREEN_WIDTH);
  display.print("x");
  display.print(SCREEN_HEIGHT);

  display.display();

  Serial.println("Look at the physical screen now:");
  Serial.println("- Where does the border rectangle actually stop being visible?");
  Serial.println("- Which corner marks are missing or cut off?");
  Serial.println("- That tells you the real width/height.");
}

void drawCornerMark(int x, int y) {
  display.drawLine(x, y, x + 8, y, SSD1306_WHITE);
  display.drawLine(x, y, x, y + 8, SSD1306_WHITE);
}

void loop() {}
