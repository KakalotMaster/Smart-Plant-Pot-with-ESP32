/ Use this code if you think your button is broken,look at the terminal for result

#define BUTTON_PIN 23

void setup() {
  Serial.begin(115200);
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  Serial.println("Button test starting...");
}

void loop() {
  int state = digitalRead(BUTTON_PIN);
  Serial.print("Button state: ");
  Serial.println(state == LOW ? "PRESSED" : "released");
  delay(200);
}
