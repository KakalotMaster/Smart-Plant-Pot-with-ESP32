#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
#define MOISTURE_PIN 32

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

void setup() {
  Serial.begin(115200);
  analogReadResolution(12);

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("OLED init failed");
    while (1);
  }
  display.setTextColor(SSD1306_WHITE);
}

void loop() {
  int raw = analogRead(MOISTURE_PIN);

  Serial.print("Raw ADC: ");
  Serial.println(raw);

  display.clearDisplay();
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.println("Calibration");
  display.setCursor(0, 20);
  display.print("Raw: ");
  display.setTextSize(2);
  display.setCursor(0, 32);
  display.println(raw);
  display.display();

  delay(300);
}
